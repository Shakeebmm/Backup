namespace PalTracker
{
    public enum TrackedOperation
    {
        Create,
        Read,
        List,
        Update,
        Delete
    }
}